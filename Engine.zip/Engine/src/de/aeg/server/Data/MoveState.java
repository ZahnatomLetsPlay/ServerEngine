package de.aeg.server.Data;

public enum MoveState {

	up, 
	up_right, 
	right, 
	down_right, 
	down, 
	down_left, 
	left, 
	up_left, 
	none
	
}
