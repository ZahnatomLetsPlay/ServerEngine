package de.aeg.server.Data;

public enum Type {

	fire,
	water,
	plant,
	fireProjectile,
	waterProjectile,
	plantProjectile,
	wall,
	none
	
}
