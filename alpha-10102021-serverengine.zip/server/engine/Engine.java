package de.aeg.server.engine;

import java.util.ArrayList;

import de.aeg.server.Data.GameObject;
import de.aeg.server.Data.MoveState;
import de.aeg.server.Data.Type;

public class Engine {
	ArrayList<GameObject> objects;
	ArrayList<GameObject> Walls;
	int Unit_Size;
	int Unit_Speed;
	int Unit_Diagonalspeed;
	int Fly_Speed;
	int Fly_Diagonalspeed;
	final int[][] bounds;

	public Engine(ArrayList<GameObject> objects, ArrayList<GameObject> Block/* , int Unit_Square, int Speed_Base */) {
		this.objects = objects;
		Walls = Block;
//		Unit_Size = Unit_Square;
//		Unit_Speed = Speed_Base;
		Unit_Size = 60;
		Unit_Speed = 5;
		Fly_Speed = 2 * Unit_Speed;
		String speedstring = (Math.ceil((Double.parseDouble(Unit_Speed + "")) / 2) + "");
		Unit_Diagonalspeed = Integer.parseInt(speedstring.substring(0, speedstring.length() - 2));
		Fly_Diagonalspeed = 2 * Unit_Diagonalspeed;
		
		bounds = new int[][] { new int[] { 0 + Unit_Size, 0 + Unit_Size }, new int[] { 1920 - Unit_Size, 1080 - Unit_Size } };
		
		System.out.println("Running");
	}

	public ArrayList<GameObject> Tick() {
		ArrayList<GameObject> changes = new ArrayList<>();
		for (GameObject p : objects) {
			int speed, dspeed;
			if (p.getHp() == 0) {
				continue;
			}
			if (p.isProjectile()) {
				speed = Fly_Speed;
				dspeed = Fly_Diagonalspeed;
			} else if (p.getType().equals(Type.none)) {
				continue;
			} else {
				speed = Unit_Speed;
				dspeed = Unit_Diagonalspeed;
			}
			int px = p.getLoc().getX();
			int py = p.getLoc().getY();
			int oy = py;
			int ox = px;
			MoveState m = p.getMove();
			boolean changed = true;
			// adjusts potential new position based on movestate
			switch (m) {
			case up:
				py -= speed;
				break;
			case up_left:
				py -= dspeed;
				px -= dspeed;
				break;
			case up_right:
				py -= dspeed;
				px += dspeed;
				break;
			case down:
				py += speed;
				break;
			case down_left:
				py += dspeed;
				px -= dspeed;
				break;
			case down_right:
				py += dspeed;
				px += dspeed;
				break;
			case left:
				px -= speed;
				break;
			case right:
				px += speed;
				break;
			case none:
				changed = false;
				break;
			}
			// sets potential new position to check collisions with other objects
			p.getLoc().setX(px);
			p.getLoc().setY(py);
			boolean no_collide = true;
			// checks collissions with walls
			for (GameObject w : Walls) {
				if (check_collision(p, w)) {
					no_collide = false;
					break;
				}
			}
			// checks collissions with other objects(players, arrows, etc)
			for (GameObject o : this.objects) {
				if (p.getId() != o.getId() && o.getHp() > 0 && !o.getType().equals(Type.none)
						&& check_collision(p, o)) {
					no_collide = false;
					System.out.println("Collider data: id " + o.getId() + ", loc " + o.getLoc() + " type "
							+ o.getType() + " health " + o.getHp());
					System.out.println("Object data: id " + p.getId() + ", loc " + p.getLoc() + " type " + p.getType()
							+ " health " + p.getHp());
					if ((o.isProjectile() && !p.isProjectile())) {
						p.setHp(p.getHp() - 1);
						if (!changes.contains(p)) {
							changes.add(p);
						}
						if (p.getHp() == 0) {
							System.out.println(p.getId() + " died");
						} else {
							System.out.println(p.getId() + " is hit");
						}
					} else if ((p.isProjectile() && !o.isProjectile())) {
						o.setHp(o.getHp() - 1);
						if (!changes.contains(o)) {
							changes.add(o);
						}
						if (o.getHp() == 0) {
							System.out.println(o.getId() + " died");
						} else {
							System.out.println(o.getId() + " is hit");
						}
					}
					break;
				}
			}
			// checks if object is moving out of screen bounds
			if (check_bounds(p)) {
				no_collide = false;
			}

			if (!no_collide) {
				p.getLoc().setX(ox);
				p.getLoc().setY(oy);
				System.out.println("Collision at: " + p.getLoc() + ", by " + p.getId() + ", type " + p.getType()
						+ ", health " + p.getHp());
				if (p.isProjectile()) {
					p.setMove(MoveState.none);
					p.setType(Type.none);
					p.setHp(0);
				}
			} else if (changed && !changes.contains(p)) {
				changes.add(p);
			}
		}
		return changes;

	}

	public boolean check_bounds(GameObject obj) {
		int x = obj.getLoc().getX();
		int y = obj.getLoc().getY();
		boolean bounds = false;
		if ((x - (0.5 * Unit_Size)) < this.bounds[0][0]) {
			bounds = true;
		} else if ((x + (0.5 * Unit_Size)) > this.bounds[1][0]) {
			bounds = true;
		}
		if ((y - (0.5 * Unit_Size)) < this.bounds[0][1]) {
			bounds = true;
		} else if ((y + (0.5 * Unit_Size)) > this.bounds[1][1]) {
			bounds = true;
		}
		return bounds;
	}

	public boolean check_collision(GameObject a, GameObject b) {
		int dx = Math.abs(a.getLoc().getX() - b.getLoc().getX());
		int dy = Math.abs(a.getLoc().getY() - b.getLoc().getY());
		double ds = Unit_Size;
		if (dx < ds && dy < ds) {
			return true;
		} else {
			return false;
		}

	}
}
