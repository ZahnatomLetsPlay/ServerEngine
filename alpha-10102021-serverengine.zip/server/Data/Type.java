package de.aeg.server.Data;

public enum Type {

	a, b, c, wall, none, arrow_a, arrow_b, arrow_c
	
}
