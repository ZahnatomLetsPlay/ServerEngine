package blocks.list;

public enum Type {

	fire,
	water,
	plant,
	fireProjectile,
	waterProjectile,
	plantProjectile,
	wall,
	none
	
}
