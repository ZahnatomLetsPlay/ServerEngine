package de.aeg.server.Data;

public class GameObject {

	private Location loc;
	private MoveState move = MoveState.none;
	private Type type = Type.none;
	private MoveState lastmove = MoveState.right;
	private int hp = 3;
	private int id;
	private String name;
	
	public GameObject(int id) {
		this.id = id;
	}
	
	public MoveState getMove() {
		return move;
	}

	public GameObject setMove(MoveState move) {
		if(move.equals(MoveState.none)) {
			this.lastmove = this.move;
		}
		this.move = move;
		return this;
	}

	public MoveState getLastMove() {
		return this.lastmove;
	}
	
	public Location getLoc() {
		return loc;
	}

	public GameObject setLoc(Location loc) {
		this.loc = loc;
		return this;
	}

	public int getHp() {
		return hp;
	}

	public GameObject setHp(int hp) {
		if (hp >= 0) {
			this.hp = hp;
		}
		return this;
	}

	public int getId() {
		return id;
	}

	public GameObject setId(int id) {
		this.id = id;
		return this;
	}

	public String getName() {
		return name;
	}

	public GameObject setName(String name) {
		this.name = name;
		return this;
	}

	public Type getType() {
		return type;
	}

	public GameObject setType(Type type) {
		this.type = type;
		return this;
	}
	
}
