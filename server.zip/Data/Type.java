package de.aeg.server.Data;

public enum Type {

	a,b,c, arrow, wall, none
	
}
