package de.aeg.server.Data;

import java.util.ArrayList;

import de.aeg.server.Server.Connection;

public class Player extends GameObject {

	private final Connection con;

	public Player(Connection con, int id) {
		super(id);

		this.con = con;
		con.write(this.getId() + "");
	}

	public void tick(ArrayList<GameObject> changes) {
		if (this.con.isConnected()) {
			String read = this.con.read();
			if (read != null) {
				String evnt = read.split(":")[0];
				String data = read.split(":")[1];
//				System.out.println(evnt + ":" + data);
				switch (evnt) {
				case "move":
					MoveState oldmove = this.getMove();
					switch (data) {
					case "w":
						this.setMove(MoveState.up);
						break;
					case "wd":
						this.setMove(MoveState.up_right);
						break;
					case "d":
						this.setMove(MoveState.right);
						break;
					case "sd":
						this.setMove(MoveState.down_right);
						break;
					case "s":
						this.setMove(MoveState.down);
						break;
					case "sa":
						this.setMove(MoveState.down_left);
						break;
					case "a":
						this.setMove(MoveState.left);
						break;
					case "wa":
						this.setMove(MoveState.up_left);
						break;
					default:
						this.setMove(MoveState.none);
						break;
					}
					if (oldmove != this.getMove()) {
						System.out.println(this.getMove().toString());
					}
					break;
				case "type":
					this.setType(Type.valueOf(data));
					break;
				}
			}
		} else {
			this.setMove(MoveState.none);
		}
	}

}
