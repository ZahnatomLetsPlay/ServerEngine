package de.aeg.server.Main;

import java.util.ArrayList;

import de.aeg.server.Data.GameObject;
import de.aeg.server.Data.Location;
import de.aeg.server.Data.MoveState;
import de.aeg.server.Data.Type;
import de.aeg.server.Server.Server;
import de.aeg.server.engine.Engine;

public class ServerMain {

	public static void main(String[] args) {
		//Server server = new Server(32768);
		//server.start();
		ArrayList<GameObject> testobjects = new ArrayList<GameObject>();
		testobjects.add((new GameObject(0)).setLoc(new Location(400,400)).setMove(MoveState.up_left).setType(Type.a));
		testobjects.add((new GameObject(1)).setLoc(new Location(100,100)).setMove(MoveState.down_right).setType(Type.b));
		testobjects.add((new GameObject(2)).setLoc(new Location(50,50)).setMove(MoveState.down_right).setType(Type.arrow));
		Engine testEngine = new Engine(testobjects, new ArrayList<GameObject>());
		for(int i = 0; i<100; i++) {
			try {
				ArrayList<GameObject> changes = testEngine.Tick();
				if(changes.size() == 0) {
					System.out.println("no changes");
					break;
				}
				System.out.println("Changes");
				for(GameObject obj : changes) {
					System.out.println(obj.getLoc() + " " + obj.getId());
				}
				System.out.println();
				Thread.sleep(50);
			} catch(InterruptedException ex) {
				ex.printStackTrace();
			}
		}
	}

}
